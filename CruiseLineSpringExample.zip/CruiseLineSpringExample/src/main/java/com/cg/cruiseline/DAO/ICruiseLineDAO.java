package com.cg.cruiseline.DAO;

import java.util.List;
import com.cg.cruiseline.DTO.CruiseLine;
import com.cg.cruiseline.exception.CruiseLineException;

// TODO: Auto-generated Javadoc
/**
 * The Interface ICruiseLineDAO.
 */
public interface ICruiseLineDAO {

	/**
	 * Adds the voyage.
	 *
	 * @param bean the bean
	 * @return the int
	 * @throws CruiseLineException the cruise line exception
	 */
	public String addVoyage(CruiseLine bean) throws CruiseLineException;

	/**
	 * Search.
	 *
	 * @param voyageId the voyage id
	 * @return the cruise line
	 * @throws CruiseLineException the cruise line exception
	 */
	public CruiseLine search(String voyageId) throws CruiseLineException;

	/**
	 * View all voyages.
	 *
	 * @return the list
	 * @throws CruiseLineException the cruise line exception
	 */
	public List<CruiseLine> viewAllVoyages() throws CruiseLineException;

	/**
	 * Delete voyage.
	 *
	 * @param voyageId the voyage id
	 * @return the cruise line
	 * @throws CruiseLineException the cruise line exception
	 */
	public CruiseLine deleteVoyage(String voyageId) throws CruiseLineException;

	/**
	 * Update voyage.
	 *
	 * @param traineeBean the trainee bean
	 * @return true, if successful
	 * @throws CruiseLineException the cruise line exception
	 */
	public boolean updateVoyage(CruiseLine traineeBean) throws CruiseLineException;
}
