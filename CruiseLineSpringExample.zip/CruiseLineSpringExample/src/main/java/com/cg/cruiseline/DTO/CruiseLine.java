package com.cg.cruiseline.DTO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// TODO: Auto-generated Javadoc
/**
 * The Class CruiseLine.
 */
@Entity
@Table(name="cruiseline")
public class CruiseLine {

	/** The voyage id. */
	@Id
	@Column(name="voyageId")
	private String voyageId;
	
	/** The voyage date. */
	@Column(name="voyageDate")
	private String voyageDate;
	
	/** The voyage destination. */
	@Column(name="voyageDestination")
	private String voyageDestination;
	
	/** The voyage amount. */
	@Column(name="voyageAmount")
	private int voyageAmount;

	/**
	 * Instantiates a new cruise line.
	 */
	public CruiseLine() {
		super();
	}

	/**
	 * Instantiates a new cruise line.
	 *
	 * @param voyageId the voyage id
	 * @param voyageDate the voyage date
	 * @param voyageDestination the voyage destination
	 * @param voyageAmount the voyage amount
	 */
	public CruiseLine(String voyageId, String voyageDate, String voyageDestination, int voyageAmount) {
		super();
		this.voyageId = voyageId;
		this.voyageDate = voyageDate;
		this.voyageDestination = voyageDestination;
		this.voyageAmount = voyageAmount;
	}

	/**
	 * Gets the voyage id.
	 *
	 * @return the voyage id
	 */
	public String getVoyageId() {
		return voyageId;
	}

	/**
	 * Sets the voyage id.
	 *
	 * @param voyageId the new voyage id
	 */
	public void setVoyageId(String voyageId) {
		this.voyageId = voyageId;
	}

	/**
	 * Gets the voyage date.
	 *
	 * @return the voyage date
	 */
	public String getVoyageDate() {
		return voyageDate;
	}

	/**
	 * Sets the voyage date.
	 *
	 * @param voyageDate the new voyage date
	 */
	public void setVoyageDate(String voyageDate) {
		this.voyageDate = voyageDate;
	}

	/**
	 * Gets the voyage destination.
	 *
	 * @return the voyage destination
	 */
	public String getVoyageDestination() {
		return voyageDestination;
	}

	/**
	 * Sets the voyage destination.
	 *
	 * @param voyageDestination the new voyage destination
	 */
	public void setVoyageDestination(String voyageDestination) {
		this.voyageDestination = voyageDestination;
	}

	/**
	 * Gets the voyage amount.
	 *
	 * @return the voyage amount
	 */
	public int getVoyageAmount() {
		return voyageAmount;
	}

	/**
	 * Sets the voyage amount.
	 *
	 * @param voyageAmount the new voyage amount
	 */
	public void setVoyageAmount(int voyageAmount) {
		this.voyageAmount = voyageAmount;
	}

}
