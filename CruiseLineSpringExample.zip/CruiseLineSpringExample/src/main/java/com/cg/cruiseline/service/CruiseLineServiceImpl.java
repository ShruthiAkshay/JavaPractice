package com.cg.cruiseline.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.cruiseline.DAO.ICruiseLineDAO;
import com.cg.cruiseline.DTO.CruiseLine;
import com.cg.cruiseline.exception.CruiseLineException;

@Service
public class CruiseLineServiceImpl implements ICruiseLineService {

	@Autowired
	ICruiseLineDAO cruiseLineDAO;

	@Override
	public List<CruiseLine> viewAllVoyages() throws CruiseLineException {
		return cruiseLineDAO.viewAllVoyages();
	}

	@Override
	public String addVoyage(CruiseLine bean) throws CruiseLineException {
		return cruiseLineDAO.addVoyage(bean);
	}

}
