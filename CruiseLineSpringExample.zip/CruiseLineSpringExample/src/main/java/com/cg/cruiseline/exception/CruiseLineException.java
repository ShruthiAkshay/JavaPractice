package com.cg.cruiseline.exception;

public class CruiseLineException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7287521990862895376L;
	
	public CruiseLineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CruiseLineException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
