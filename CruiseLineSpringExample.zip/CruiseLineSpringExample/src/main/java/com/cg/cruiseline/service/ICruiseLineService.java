package com.cg.cruiseline.service;

import java.util.List;

import com.cg.cruiseline.DTO.CruiseLine;
import com.cg.cruiseline.exception.CruiseLineException;

public interface ICruiseLineService {
	
	public List<CruiseLine> viewAllVoyages() throws CruiseLineException;
	
	public String addVoyage(CruiseLine bean) throws CruiseLineException;
}
