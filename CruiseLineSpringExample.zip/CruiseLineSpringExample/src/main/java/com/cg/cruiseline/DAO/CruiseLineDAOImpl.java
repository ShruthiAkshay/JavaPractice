package com.cg.cruiseline.DAO;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.cruiseline.DTO.CruiseLine;
import com.cg.cruiseline.exception.CruiseLineException;


@Repository
@Transactional
public class CruiseLineDAOImpl implements ICruiseLineDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public String addVoyage(CruiseLine bean) throws CruiseLineException {

		String id = null;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id = bean.getVoyageId();
		} catch (Exception e) {
			throw new CruiseLineException("unable to persist in Dao Layer" + e.getMessage());
		}
		return id;
	}

	@Override
	public CruiseLine search(String voyageId) throws CruiseLineException {
		CruiseLine voyage = new CruiseLine();

		return voyage;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CruiseLine> viewAllVoyages() throws CruiseLineException {
		List<CruiseLine> voyageList = null;
		try {
			TypedQuery<CruiseLine> query = (TypedQuery<CruiseLine>) entityManager
					.createNativeQuery("select c from CruiseLine c", CruiseLine.class);
			System.out.println(query);
			voyageList = query.getResultList();
		} catch (Exception e) {
			throw new CruiseLineException("unable to view all records in Dao layer" + e.getMessage());
		}
		return voyageList;
	}

	@Override
	public CruiseLine deleteVoyage(String voyageId) throws CruiseLineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateVoyage(CruiseLine traineeBean) throws CruiseLineException {
		// TODO Auto-generated method stub
		return false;
	}

}
