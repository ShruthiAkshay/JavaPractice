package com.cg.cruiseline.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.cg.cruiseline.DTO.CruiseLine;
import com.cg.cruiseline.exception.CruiseLineException;
import com.cg.cruiseline.service.ICruiseLineService;

@Controller
public class CLController {

	@Autowired
	private ICruiseLineService cruiseLineService;

	@RequestMapping("/showHome")
	public String showHomePage() {
		return ("index");
	}

	@RequestMapping("/addVoyageForm")
	public String traineeForm() {
		return ("addVoyage");
	}

	@RequestMapping(value = "addVoyageDetails", method = RequestMethod.POST)
	public ModelAndView addTrain(@ModelAttribute("voyage") CruiseLine bean, BindingResult result) {
		ModelAndView mv = new ModelAndView();

		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		} else {
			try {
				String id = cruiseLineService.addVoyage(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("voyage", bean);
			} catch (CruiseLineException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}

		return mv;
	}

	@RequestMapping("viewAllVoyages")
	public ModelAndView viewall(@ModelAttribute("voyages") CruiseLine bean) {
		ModelAndView mv = new ModelAndView();
		try {
			List<CruiseLine> list = cruiseLineService.viewAllVoyages();
			mv.setViewName("viewAll");
			mv.addObject("list", list);
			return mv;
		} catch (CruiseLineException c) {
			mv.setViewName("error");
			mv.addObject("message", c.getMessage());
		}

		return mv;
	}

}
