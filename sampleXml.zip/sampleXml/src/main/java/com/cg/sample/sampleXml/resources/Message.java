package com.cg.sample.sampleXml.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.sample.sampleXml.model.Student;
import com.cg.sample.sampleXml.service.StudentService;

@Path("/messages")
public class Message {
	
	StudentService studentService = new StudentService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Student> getMessages(){
		return studentService.getAllStudents();
	}
	
	@GET
	@Path("/{studentId}")
	@Produces(MediaType.APPLICATION_XML)
	public Student getStudent(@PathParam("studentId") long studentId){
		return studentService.getStudent(studentId);
	}
}
