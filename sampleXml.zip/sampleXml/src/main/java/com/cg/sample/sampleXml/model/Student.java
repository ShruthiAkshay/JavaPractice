package com.cg.sample.sampleXml.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student {
	
	private long studentId;
	private String studentName;
	private Date studentDOJ;
	private String studentSchool;
	
	
	public Student() {
		super();
	}
	
	
	public Student(long studentId, String studentName,
			String studentSchool) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentDOJ = new Date();
		this.studentSchool = studentSchool;
	}


	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Date getStudentDOJ() {
		return studentDOJ;
	}
	public void setStudentDOB(Date studentDOJ) {
		this.studentDOJ = studentDOJ;
	}
	public String getStudentSchool() {
		return studentSchool;
	}
	public void setStudentSchool(String studentSchool) {
		this.studentSchool = studentSchool;
	}
	
}
