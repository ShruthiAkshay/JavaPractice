package com.cg.sample.sampleXml.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.sample.sampleXml.model.Student;

public class StudentService {
	Student s1 = new Student(1L, "Shruthi", "Websters");
	Student s2 = new Student(2L, "Swathi", "HolyChild");

	public List<Student> getAllStudents() {
		List<Student> studentList = new ArrayList<>();
		studentList.add(s1);
		studentList.add(s2);
		return studentList;
	}

	public Student getStudent(long studentId) {
		if (studentId == 1L) {
			return s1;
		} else {
			return s2;
		}
	}
}
